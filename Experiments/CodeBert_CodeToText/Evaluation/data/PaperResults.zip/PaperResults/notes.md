config 21 is the reference file

