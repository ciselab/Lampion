ho "Packing results found in ./configs" 

folders=`find ./configs -maxdepth 1 -mindepth 1 -type d`

for config_folder in $folders; do
	    [ -e "$config_folder" ] || continue
	        echo "running extractor in folder $config_folder"
		    rm -rf "$config_folder/model"
		        rm -rf "$config_folder/dataset"
			    rm -rf "$config_folder/ur_dataset"
			        mv "$config_folder/experiment_output/test_0.gold" "$config_folder"
				    mv "$config_folder/experiment_output/test_0.output" "$config_folder"
				        rm -rf "$config_folder/experiment_output"
				done
